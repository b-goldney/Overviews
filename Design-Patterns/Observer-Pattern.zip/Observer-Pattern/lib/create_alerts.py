def create_alerts(ticker: str) -> None:
    print("creating news alerts for ticker {ticker}")
