def send_email(email: str, name: str, subject: str, body: str) -> None:
    print(f"\n--- Send email to {name} at {email}")
    print(f"Subject: {subject} \nBody: {body}")
