def update_database(action, quantity: int, price: float):
    print(
        f"\n--- updating the db with action: {action}, quantity: {quantity}, price: {price}"
    )
