from enum import Enum

# trade types
class TradeActions(Enum):
    BUY = "buy"
    SELL = "sell"
